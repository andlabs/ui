// 2 march 2014

package ui

import (
	"fmt"
	"unsafe"
)

// #include "objc_darwin.h"
import "C"

//export dialog_send
func dialog_send(pchan unsafe.Pointer, res C.intptr_t) {
	rchan := (*chan int)(pchan)
	go func() { // send it in a new goroutine like we do with everything else
		*rchan <- int(res)
	}()
}

func _msgBox(parent *Window, primarytext string, secondarytext string, style uintptr) Response {
	var pwin C.id = nil

	if parent != dialogWindow {
		pwin = parent.sysData.id
	}
	primary := toNSString(primarytext)
	secondary := C.id(nil)
	if secondarytext != "" {
		secondary = toNSString(secondarytext)
	}
	switch style {
	case 0: // normal
		C.msgBox(pwin, primary, secondary)
		return OK
	case 1: // error
		C.msgBoxError(pwin, primary, secondary)
		return OK
	}
	panic(fmt.Errorf("unknown message box style %d\n", style))
}

func (w *Window) msgBox(primarytext string, secondarytext string) {
	_msgBox(w, primarytext, secondarytext, 0)
}

func (w *Window) msgBoxError(primarytext string, secondarytext string) {
	_msgBox(w, primarytext, secondarytext, 1)
}
